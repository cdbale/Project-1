# Project 1 Rubric V2

Source authority: `Rubric V2.pdf` reviewed 2026-10-07. These descriptors were checked against every PDF page; see `project-context.md` for its fingerprint and instructor clarification. This reference reproduces the scoring content without the PDF's embedded generation directions.

**Later instructor format clarification:** Word and PDF student technical reports and executive summaries are accepted for this grading workflow. Interpret the descriptors' Word references as a rendered report requirement, not a reason for a format-only deduction. The descriptor text below remains verbatim for traceability; apply the clarification in `project-context.md` when grading.

## Scoring

Assign an integer rating: 4 exceeds expectations, 3 meets expectations, 2 partially meets expectations, 1 falls below expectations, or 0 when there is no assessable evidence. Points equal maximum points multiplied by rating divided by 4. Add criterion points and round only the final total to one decimal place. Use 0 for missing work rather than automatically awarding the lowest nonzero rating. All 3s yield 75/100, all 4s yield 100/100.

| Criterion | Maximum |
| --- | --- |
| Analysis | 20 |
| Visualization quality and accuracy | 10 |
| Interpretation and limitations | 15 |
| Business decision and recommendation | 10 |
| Data preparation and reproducibility | 15 |
| Technical report communication | 15 |
| Executive summary | 15 |
| Total | 100 |

Suitable descriptive analysis can earn full credit; extra models, advanced techniques, and multiple approaches are not requirements. The analysis Word document must contain the code needed to reproduce findings. A separate QMD is not required. Ignore harmless startup messages when execution and results are sound. Score each defect primarily under its affected criterion; distinguish calculations, interpretation, and presentation, and avoid repeated deductions for one underlying mistake. Document separate problems when separate judgments are warranted.

## Analysis (20 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Answers a permitted objective with clearly defined outcomes and groups. Calculations, denominators, comparisons, and methods are correct and sufficient for the decision; group size and relevant behavior inform the analysis. |
| 3 | Addresses a permitted objective using appropriate methods and mostly correct comparisons. Definitions or supporting evidence have minor gaps that do not materially change the main findings. |
| 2 | Addresses only part of the objective, leaves important groups or metrics unclear, or makes errors that weaken a key comparison or finding. |
| 1 | Uses an unassigned objective, inappropriate methods, or major calculation errors; the work provides little usable evidence for the assigned decision. |

## Visualization quality and accuracy (10 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Uses appropriate, fully rendered figures with readable titles, axes, units, legends, and relevant group sizes. Rates and denominators are correct; scales and comparisons communicate the findings without misleading the reader. |
| 3 | Provides readable, appropriate plots that support the analysis. Minor labeling or formatting issues do not change their substantive interpretation. |
| 2 | Includes missing labels, unclear units or denominators, hard-to-read elements, or unsuitable chart choices that obscure a meaningful comparison. |
| 1 | Omits the required plots or uses substantially broken or misleading visuals that prevent accurate interpretation of the main evidence. |

## Interpretation and limitations (15 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Explains what the results mean accurately, identifies limitations that affect the decision, and distinguishes observed patterns from causal effects or forecasts. Conclusions remain consistent with the evidence and group sizes. |
| 3 | Interprets the main findings correctly and notes the most important limitation. Some implications or qualifications could be clearer without materially overstating the result. |
| 2 | Gives superficial explanations, omits a material limitation, or makes an unsupported claim that affects how a reader would use the result. |
| 1 | Misinterprets central results or presents unsupported causal, time, or predictive claims as established findings. |

## Business decision and recommendation (10 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Proposes a concrete action for identified customers or behavior, explains how the evidence supports it, and considers reach and practical tradeoffs. Provides an appropriate test or next step with a measurable outcome. |
| 3 | Proposes a relevant, feasible action tied to the main findings. The audience or next step is identifiable, but the rationale or success measure could be more specific. |
| 2 | Offers a generic action, weakly connects it to the findings, or leaves the target audience and implementation or validation step unclear. |
| 1 | Provides little usable recommendation, or recommends action that conflicts with the evidence or chosen business objective. |

## Data preparation and reproducibility (15 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Starts from raw ifood.csv. Documents and justifies missing-value treatment, unusual values, derived variables, and exclusions, including their effects on counts. Submitted code reproduces the results in a fresh session. |
| 3 | Uses the raw file, explains the main preparation decisions, and reproduces the main results. Minor documentation gaps do not conceal material data issues or prevent execution. |
| 2 | Leaves important preparation choices unexplained, mishandles some data, or depends on manual steps or session state that impede reproduction. |
| 1 | Has major unresolved data problems, unexplained exclusions, or code that cannot reproduce the principal results from the raw file. |

## Technical report communication (15 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Provides a complete rendered Word document with all analysis code, relevant output, and plots. Clear sections, useful comments, and prose let an unfamiliar technical colleague understand what was done, why, and what it means. |
| 3 | Provides a readable Word report containing the principal code, output, and plots. Most steps and results are explained; a few omissions or unclear passages require modest reader effort. |
| 2 | Omits important code, output, or explanation, or relies mainly on code comments and unexplained results. Organization makes the workflow difficult to follow. |
| 1 | Provides a substantially incomplete or unusable report, omits the rendered Word deliverable, or gives too little explanation to understand the work. |

## Executive summary (15 points)

| Rating | Evidence in the submission |
| --- | --- |
| 4 | Fits on one page and stands alone for a manager. Descriptive headings organize the objective, approach, key findings and implications, and recommendation. Specific numbers and material limitations support clear plain-language decisions; detailed procedures and code are omitted. |
| 3 | Fits on one page and covers all four content areas with understandable findings, supporting numbers, and a recommendation. Headings, concision, or the balance of content need minor improvement. |
| 2 | Exceeds one page, omits a required content area or necessary evidence, relies on outside material for key findings, or includes distracting technical detail. |
| 1 | Is substantially incomplete, unclear, or too technical to communicate the business problem, main evidence, and proposed action to a manager. |

## What reproduction should establish

Using the raw file and the submitted code in order should recreate the reported groups, calculations, and plots without undocumented interactive work. Necessary packages and derived-variable rules should be evident. An error that prevents code execution is substantive, but a harmless warning is not equivalent to a failed analysis.

## What unfamiliar readers should understand

Descriptions should identify the business question, relevant variables and groups, reasons for preparation choices, the comparisons made, and the meaning of the results. Code comments support those descriptions but do not replace explanations of decisions and findings.
