# Canvas intake and local grading outputs

Use this procedure for the skill's first task in a new grading run. It collects the original submissions and creates a local AI assessment record. It does not publish grades or replace the TA's personal assessment and reconciliation.

This is the **overseer's** procedure. Assessment workers do not perform class intake. After collection, follow [overseer-and-assessment-agents.md](overseer-and-assessment-agents.md) to create a new no-history assessment agent per student. Only the overseer updates the root CSV; workers own only their assigned student outputs.

## Ask for location and verify scope

Ask the TA: **"Which parent folder on your computer should contain Project_1_Grading?"** If they already specified a path, use it. Also obtain the intended Canvas course/term, section scope, and Project 1 assignment if these cannot be established unambiguously from their request and available Canvas metadata. These are setup questions, not requests for TA grading decisions.

Resolve the chosen absolute path and create `<chosen parent>/Project_1_Grading`. If the root already exists, inspect its run metadata and preserve existing work; do not clear it. Resume a matching run or ask about a course/assignment mismatch before mixing cohorts. Obtain any required local filesystem permission for that actual path through the normal tool mechanism.

Verify the course, term, sections, and assignment(s) in Canvas; do not reuse Cam's or another TA's remembered IDs. If the executive summary and technical report use separate assignments, record both IDs and associate files by student ID. Obtain a full student roster for the agreed sections, including students with no downloadable submission. Exclude TA/teacher/test-student enrollments unless explicitly included. If permissions prevent a complete roster or submission list, report the incomplete coverage rather than calling the collection complete.

Deduplicate by Canvas user ID within the verified course. Resolve names and section memberships from Canvas, not uploaded filenames. If a student has multiple relevant sections, keep one student row and list the verified section names in a deterministic semicolon-separated cell, retaining section IDs in metadata. Flag unavailable or ambiguous section membership for TA clarification instead of guessing.

## Access route

### Configured Canvas API first

Use the TA's existing, approved Canvas API tooling and their own account credentials. Do not copy Cam's credential, distribute a token, ask for one in chat, or print/decrypt it into tool output. A TA need not set up the API if their connected browser plugin can complete the task.

If this course workspace's Windows helper is available, read `tools/canvas/README.md` and start with `canvas.ps1 -Action Check`, then `-Action Courses`. Authenticated calls require the normal `require_escalated` execution path in Codex because the restricted sandbox cannot decrypt its Windows DPAPI credential or reach Canvas. Retry a sandbox-only credential failure with those permissions before treating it as a broken setup. If the credential really is absent/expired, offer the browser route; if the TA chooses API setup, have them run `-Action Setup` in their own terminal. Never substitute the instructor's account.

Use paginated read endpoints to obtain roster/sections and assignment attachments. Typical paths, with **verified** IDs, are:

```text
GET /api/v1/courses/{course_id}/enrollments?type[]=StudentEnrollment&per_page=100
GET /api/v1/courses/{course_id}/sections?per_page=100
GET /api/v1/courses/{course_id}/assignments?per_page=100
GET /api/v1/courses/{course_id}/assignments/{assignment_id}/submissions?per_page=100
GET /api/v1/courses/{course_id}/assignments/{assignment_id}/submissions/{user_id}
GET /api/v1/files/{file_id}
```

Follow every pagination link, and filter enrollments to the agreed roster/status and section scope. A missing submission-list record is a reason to investigate with the single-student endpoint, not a reason to omit that student. Capture the current submitted attempt and timestamp at collection time. Follow a provided grading cutoff/attempt rule; otherwise collect the latest submitted attempt and record that choice. Never silently combine files from different attempts or substitute an earlier complete attempt for a current incomplete one. Flag ambiguities for TA guidance.

**Protect blinding at the tool boundary.** Submission responses can contain `score`, `grade`, and grading metadata even without optional includes. Enrollment responses can contain grade information too. Do not display or save raw response objects. In a shell/API wrapper, fetch internally and select an allowlist **before** returning tool output to the model or saving intake files: course/assignment/user IDs; student name; section IDs/names; submission type; attempt; submitted timestamp; attachment IDs, names, MIME types, sizes, and download information needed internally. Omit existing scores, grades, rubric assessments, grader identity, comments, annotations, and other human assessment fields. Do not request assessment/comment associations. If submission history is needed to resolve an attempt, filter it with the same allowlist.

For the local helper, `canvas.ps1 -Action Get` prints a full JSON result. For endpoints that may include human assessments, call `Invoke-CanvasApi` inside a PowerShell command/script and project only allowed properties before printing or saving. Do not dump the full result for convenience and filter after the model has seen it.

Download the original attachments using the approved file-download capability or URLs returned by authenticated Canvas file/submission metadata. Use an HTTPS binary downloader, keep authorization headers on the configured Canvas origin, and never forward a bearer token to a redirect or different file-storage host. Use a Canvas-issued signed download URL without a bearer header when appropriate; do not log its secret query parameters. The local JSON helper does **not** implement binary downloads, so do not pass binary responses through it or claim an attachment was downloaded from metadata alone. If a supported downloader is unavailable, use the browser plugin.

### Browser plugin fallback

Use the TA's connected browser/plugin and its documented navigation/download tools. Discover the relevant Canvas tab or open the TA's Canvas site; have the TA complete login if needed. Verify course/term, section scope, assignment, and complete roster there. Use original submission download controls or a bulk submission download when available. Follow all roster/listing pages and unpack any bulk archive into the correct student folders only after verifying student and attempt associations. Avoid relying on archive filenames alone for identity.

Keep the model away from Gradebook, rubric scores, TA comments, and annotated/graded copies. Do not export gradebook scores as intake metadata. If a required UI view exposes a prior assessment, disclose the exposure and perform the independent grading in a fresh context that receives only original submission files and filtered intake metadata. Do not claim a contaminated assessment was blind. If neither route is connected or permitted, explain the specific access blocker and ask the TA to connect/login or supply the downloaded originals and roster. Do not fabricate roster coverage or student files.

## Folder and intake record

Use one collision-safe student folder such as `<Canvas user ID>_<sanitized student name>`. Remove invalid filename characters, reserved names, and path components from downloaded filenames; ensure resolved destinations remain under the chosen grading root. Keep Canvas user ID as the stable identity. Preserve the original readable display filename in the intake record if sanitization or collision suffixes are needed.

```text
Project_1_Grading/
  AI_Assigned_Scores.csv
  run_manifest.json
  12345_Student_Name/
    Executive_Summary.pdf        (actual original name/format may differ)
    Technical_Report.docx        (actual original name/format may differ)
    submission_manifest.json
    AI_Assessment.xlsx
    assessment_result.json
```

The two original filenames above illustrate deliverable roles, not required names or file counts. Download all relevant submitted attachments, identify roles from their content, and note extras. If a single clearly organized file contains both deliverables, record the section/page locations and evaluate both; flag it only if separation, completeness, or one-page summary compliance cannot be established. Preserve originals. Keep converted/rendered inspection copies distinct, and cite their pagination as a rendered copy when the source lacks stable page numbers.

`run_manifest.json` should identify the course/term/section scope, assignment IDs, roster coverage/count, collection time, attempt-selection rule, grading packet/skill version, access route, and run/model identifier where available. `submission_manifest.json` should identify the student and section, chosen attempt(s), original attachment IDs/names, local paths, hashes and sizes, identified deliverable roles, intake checks, unresolved flags, and any TA intake clarification. Do not include Canvas credentials, secret download URLs, or human grading fields.

Check that each download exists, is nonempty, matches the expected file type, and actually opens as a document rather than an HTML login/error page. Word `.docx`, readable legacy `.doc`, and PDF are acceptable for either deliverable under Cam's clarification. A PDF technical report does not receive a format-only penalty. Other formats, encrypted/corrupt files, missing required content, ambiguous deliverable roles, access failures, and absent attachments require a student-specific flag.

## Missing or unexpected submission handling

Create the student's folder and CSV row even if collection fails. Record the exact missing/unexpected file or content, checks performed, and needed decision in their manifest and pending assessment spreadsheet. Set `assessment_status=needs_ta_review`, add a concise `review_flags` description, and leave unresolved ratings/points and the overall grade empty. Present the affected student IDs/names, sections, problem, and a focused request for the TA to investigate and advise: for example, locate a replacement file, confirm the intended attempt/deliverable, provide a readable copy, or confirm that no work was submitted.

Continue collecting and assessing unaffected students while waiting. Do not ask for the TA's rubric ratings or review comments to resolve an intake problem. A confirmed entire absence of assessable work can receive 0, with an absence-based evidence record; a retrieval error, unexplained format, or uncertain submission is not confirmed absence. If only some categories are defensibly assessable, record those ratings with appropriate evidence/status but withhold the overall grade until all categories and consequential intake issues are resolved. Never prorate a partial grade to 100.

## Root CSV schema

Create `AI_Assigned_Scores.csv` as soon as the verified roster is available, with one row per student and initially empty score cells. Update that student's row after their independent assessment; do not append duplicate rows on reruns. Use Canvas course/user IDs as the update key. This file tracks **AI-assigned assessments**, with no TA ratings or median grades.

Use these columns, in this order:

```text
student_name,section,student_id,course_id,
analysis_rating,analysis_points,
visualization_quality_accuracy_rating,visualization_quality_accuracy_points,
interpretation_limitations_rating,interpretation_limitations_points,
business_decision_recommendation_rating,business_decision_recommendation_points,
data_preparation_reproducibility_rating,data_preparation_reproducibility_points,
technical_report_communication_rating,technical_report_communication_points,
executive_summary_rating,executive_summary_points,
overall_grade,penguin_sentence_present,assessment_status,review_flags,student_folder,assessment_spreadsheet
```

The line breaks above are for readability; write one CSV header row. Rating columns contain integers 1-4, or 0 for confirmed no assessable evidence. Use **empty cells**, not 0, for pending/unverified ratings, points, and totals. A criterion point column is exactly `maximum * rating / 4`. Maxima in the same order are 20, 10, 15, 10, 15, 15, and 15. Sum exact criterion points and round only `overall_grade` to one decimal using the documented calculator convention. Use `scripts/score.py` or an equivalent deterministic calculation, not manually guessed conversions. Preserve values such as 3.75 in criterion columns.

`penguin_sentence_present` is a separate presence indicator for the exact wording **`The marketing penguin has misplaced its spreadsheet.`** in the student's original files for the selected submission attempt. Write 1 when at least one occurrence is verified, even if another file remains unreadable; write 0 only after all original submission files have been checked with no occurrence, or the TA has confirmed no submission exists. Leave it empty while presence/absence is unresolved, and explain the incomplete check in `review_flags`. Search extracted text with case and whitespace normalization to handle line wrapping/Word text runs; inspect rendered pages or use OCR when needed before declaring a scanned/image-only file negative. Keep the words exact; paraphrases such as "has lost its spreadsheet" do not establish this indicator.

Search only student submission originals, not the assignment/rubric PDFs, copied grading packet, skill text, generated AI assessment spreadsheet, or tracker. For a positive result, record the original filename and page/section/paragraph locator in `submission_manifest.json` and the spreadsheet's instructor-only review flags, and include a short occurrence note in `review_flags`. The indicator is per student across their selected submission files, not a count of occurrences or a rubric rating. It never enters criterion points, overall grades, or the median and implies no misconduct. When resuming an older tracker, add this column without replacing existing data; leave it blank until the corresponding originals have actually been checked.

Statuses: `pending_intake` before inspection, `needs_ta_review` for consequential intake/format issues, `provisional` for clearly labeled unresolved verification, and `complete` for a defensible full independent assessment. An informational instructor flag, such as the penguin sentence, may accompany `complete` without changing points. `student_folder` and `assessment_spreadsheet` use paths relative to the grading root; leave a report path empty until that file actually exists. `review_flags` must describe pending problems instead of relying on a score cell to signal them.

Write UTF-8 CSV with a real CSV writer (for example Python `csv.DictWriter`) and proper quoting for commas, quotes, and newlines in names/section labels. Keep rating/point/grade cells numeric literals or empty; do not use spreadsheet formulas. Save updates through a temporary file and replace the tracker only after validation, preserving prior AI outputs when revising a completed assessment. Never alter TA reconciliation files.

## Per-student spreadsheet and completion checks

Create `AI_Assessment.xlsx` in each student folder. Its primary worksheet, `Assessment`, has exactly these six columns, with one row for each of the seven rubric criteria:

| Criterion (maximum) | Rating (0-4 or withheld) | Exact points | Submission evidence and locator | Why this descriptor fits | Uncertainty or boundary check |
| --- | --- | --- | --- | --- | --- |

Use the exact criterion names, including each maximum in the first column (for example, `Analysis (20)`). Rating cells contain an integer 0-4 or the text `withheld`; exact-point cells are numeric values or empty when withheld. Keep all evidence and rationale text intact, including at least one located evidence item per selected rating. For withheld ratings, document the unavailable evidence and required check/TA action in the evidence, rationale, and uncertainty fields. Do not invent a rating or use 0 for an unresolved check. Put the overall total/status below the seven-row table, without turning it into an eighth rubric criterion. Apply the same exact point calculations and final-total rounding as the root CSV.

Use a separate `Review details` worksheet for student identity/section, Canvas attempt and submission time, files reviewed, packet/skill/model version, worker ID and actual no-history setting, blinding status, calculation/reproduction checks, verification limits, issue list, concise feedback, and labeled instructor-only flags (including the penguin indicator and its source location). These notes must not change the requested six-column assessment table. For pending students, retain all seven criterion rows and clearly identify unresolved intake/status and needed TA action. The workbook is for TA review, not automatic student distribution.

Workers use available local spreadsheet creation tools. Set useful column widths, wrap the evidence, rationale, and uncertainty columns, and expand row heights so evidence is fully readable. Freeze the header, keep numeric ratings/points distinct from prose, and avoid merged cells inside the assessment table. Reopen the workbook and verify the six headers, seven criteria, numeric types, evidence/rationale completeness, and total; visually inspect the table to catch clipped text. Return the structured result; the overseer checks agreement with the root CSV without exposing it to workers. If spreadsheet generation is blocked, flag the output problem and preserve an explicit interim report rather than claiming an XLSX exists. The **student's executive summary**, not this workbook, is subject to the one-page requirement.

The root tracker now uses `assessment_spreadsheet` for the relative path to the student's XLSX. When resuming an older run, preserve any earlier AI reports, migrate the tracker link field, and populate the new path only after the spreadsheet actually exists and has been checked. Keep original student Word/PDF files unchanged.

Before declaring the run complete, reconcile the verified roster, student folders, CSV rows, and assessment spreadsheets. Verify uniqueness, student/section identity, original file associations, rating ranges, point conversions, `penguin_sentence_present` values (0, 1, or unresolved blank), and CSV/spreadsheet agreement, including located evidence for a positive indicator. Every roster student must have a row and folder, with either a complete assessment or an explicit pending issue. Report counts of roster students, downloaded/assessed submissions, and flagged/pending students; never silently drop an exception. Preserve the AI report and tracker for personal TA reconciliation. Final TA ratings and the median of final TA totals are separate records.

## Canvas documentation

Endpoint and field behavior was checked against the official Canvas documentation on 2026-10-07. Use these primary references when adapting to a different client or changed API:

- [Submissions API](https://developerdocs.instructure.com/services/canvas/resources/submissions)
- [Enrollments API](https://developerdocs.instructure.com/services/canvas/resources/enrollments)
- [Files API and downloads](https://developerdocs.instructure.com/services/canvas/resources/files)
- [Pagination](https://developerdocs.instructure.com/services/canvas/basics/file.pagination)
