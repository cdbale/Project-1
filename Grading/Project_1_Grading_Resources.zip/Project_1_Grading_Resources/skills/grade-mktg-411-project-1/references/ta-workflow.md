# TA workflow and grading records

An AI overseer creates a fresh assessment agent for each student, without inherited grading context, and collects its independent report. The TA personally reconciles it with their own initial assessment and decides the final ratings. Every TA completes this process for every student; each student's final project grade is the median of final TA totals. Preserve records privately in an instructor-approved location.

## First TA task and final grade entry

The TA team first copies the previous semester's Google Drive grading spreadsheet for this semester's sections. Update the roster and TA assignments, clear old student data/grades, preserve the structure and median formulas, and share one new spreadsheet with the instructor. Retain verified student IDs and sections, a designated grade-entry area for each TA, protected median formulas, and an explicit way to track unresolved grades.

After personal reconciliation, each TA enters their own finalized total out of 100 in the designated area of that shared spreadsheet. The existing formulas calculate the median across final TA totals. The instructor checks completeness/medians and identifies approved rows; assigned TAs then post the approved final values to Canvas following the release plan. These human tasks are separate from the overseer's AI-only tracker and read/download-only Canvas access.

## Collect submissions and create the grading directory

The model's first task in a new run is Canvas collection and organization under [canvas-intake-and-outputs.md](canvas-intake-and-outputs.md). It asks where you want `Project_1_Grading`, verifies the course/term/sections and assignment, uses your configured Canvas API or connected browser plugin, and creates one student folder and one root CSV row per roster student. It downloads original Word/PDF submissions, including both executive summary and technical report, without reading TA grading fields. Missing/unexpected or unreadable submissions are flagged for your investigation and intake guidance; the agent continues with unaffected students.

The root `AI_Assigned_Scores.csv` records the student's name, section, seven integer AI ratings and converted criterion points, overall AI grade out of 100, status, and file locations. It also includes `penguin_sentence_present`: 1 for a verified occurrence of `The marketing penguin has misplaced its spreadsheet.` in any original student submission file, 0 for verified absence, or blank if the check is unresolved. A positive result has a source locator in the instructor-only review flags and does not change grades. Each student's `AI_Assessment.xlsx` supplies the supporting evidence and justifications; pending students receive an explicit status report. Keep your initial assessment and final reconciliation records outside this AI collection/assessment directory. Your role is to review the original work, save your own initial judgments before reading AI results, and personally reconcile afterward.

## Before grading the class

- Freeze and distribute the same instruction PDF, Rubric V2 PDF, raw data, skill version, and instructor clarifications to all TAs. This skill contains a baseline reviewed on 2026-10-07. Confirm that it matches the release students received. Record an identifier/hash for the grading packet and skill revision in the log.
- Read the rubric descriptors and scoring scale before starting. A set of 3s is 75/100; do not rescale it to full credit.
- Use the same AI model/configuration and review tools where practical, and record the available model identifier and date. A consistent model does not guarantee consistent or correct grades. Keep TA judgments independent and treat the AI report as a second assessment that requires verification.
- If the same AI report is reused by multiple TAs, label it as shared. Their AI advice is then correlated; the median cannot eliminate a systematic error all graders adopt. An instructor spot-check can identify shared mistakes. Avoid repeatedly rerunning a student until a preferred score appears.

## For each student and each TA

1. Read the full submission yourself using the rubric. Save seven initial integer ratings, at least one located evidence item and rationale for each, and the calculated initial total. Include evidence for full credit as well as deductions. Keep this assessment private from the AI and other TAs during their independent assessment.
2. Start a fresh overseer session with the skill, official packet, verified intake, originals, and raw data. Exclude your assessment, other TAs' comments, gradebook views, and prior AI reports. The overseer must create a new assessment agent for each student with no inherited conversation/grading history, passing only common materials and that student's allowed input paths. It alone updates the class CSV. Workers do not access other students, trackers, the shared final-grade spreadsheet, or other agent results. If no-history delegation is unavailable, keep assessment pending and choose separate fresh student chats rather than a shared-context batch. See [overseer-and-assessment-agents.md](overseer-and-assessment-agents.md). Keep initial TA records outside the AI's accessible assessment folder.
3. Obtain and save the independent AI report. Verify the cited evidence and consequential recalculations yourself. Treat invented locators, missing files, reproduction claims without execution, or unexplained ratings as reasons to correct the report. Ask the AI to recheck the specific evidence without supplying a desired rating. Preserve its initial report and any correction with reasons.
4. Personally compare **all seven categories**, including agreements. For a disagreement, identify whether it concerns a fact, a calculation, an interpretation, a descriptor boundary, or source ambiguity. Recheck the original submission and rubric. Keep or change your own rating based on evidence; agreement with the AI is not a goal. Do not average the two ratings or give the AI a vote.
5. Save final TA ratings, located evidence for every final selection, and reasons for keeping/changing choices. Recompute the final total. Keep instructor-only flags separate from feedback to the student. Send unresolved consequential source/policy questions to the instructor before finalizing; do not invent penalties.

The default AI task stops at step 3. The TA performs steps 4-5 personally. Optional later AI help with a comparison requires an explicit request and is labeled as reconciliation after the blind report, not a new independent assessment.

## Copyable blind-assessment prompt

For collecting and assessing the course roster:

```text
Use $grade-mktg-411-project-1 as the overseer for a Project 1 grading run.
First ask where I want
Project_1_Grading and verify the Canvas course, term, sections, and assignment.
Use my configured Canvas API if available; otherwise use my connected browser
plugin. Download each roster student's original executive summary and technical
report into their student folder. Accept Word or PDF files. Flag missing,
unexpected, or unreadable submissions for my investigation and intake advice.
Do not read existing Canvas grades, rubric scores, TA comments, or my assessment.
After intake, create a new assessment agent for each student with no inherited
conversation or prior grading context (fork_turns="none" where supported).
Give it only common grading materials and its student's originals/intake.
Do not reuse agents across students. Workers must create AI_Assessment.xlsx
and return seven ratings, exact points, evidence, rationale, and uncertainty.
Only you, the overseer, update AI_Assigned_Scores.csv. Queue within the available
agent limit and check completeness/arithmetic without adjusting rating judgments.
If fresh-context delegation is unavailable, report the blocker and leave
assessment pending; do not grade the batch in your own shared context.
Include penguin_sentence_present (1 present, 0 absent, blank unresolved) for the
exact sentence in the original submissions; its presence never changes scores.
Leave unresolved scores empty and identify the TA action needed. I will save my
own assessment before reading AI results and personally reconcile the decisions.
```

For a single submission already supplied locally:

```text
Use $grade-mktg-411-project-1 as overseer to create a new no-history assessment
agent for submission [submission ID].
Use the supplied Project 1 Instructions.pdf and Rubric V2.pdf, with the skill's
instructor clarification that the penguin sentence is a review flag only and has
no point deduction. Attached are the complete submitted analysis document,
executive summary, and raw ifood.csv. You have not been given my assessment.
Do not ask for or read TA assessments. Give the worker only the common materials
and this student's originals/intake, without your conversation history or any
prior grading results. The worker must read the full submission, inspect rendered
figures and layout, and check reproducibility where your tools allow.
Return all seven integer ratings, exact weighted points, specific located
evidence and a descriptor-based rationale for every choice, the total, and
verification limitations. Distinguish inaccessible evidence from missing work.
Keep review flags separate from student-facing feedback. Stop with the report;
I will personally reconcile it with my own previously saved assessment.
```

Replace the bracketed submission ID and specify any confirmed newer packet or additional instructor clarification. Do not include your grades or evidence selections.

In either mode, Word and PDF student reports are acceptable under Cam's format clarification. The CSV is an AI score tracker, not a place for your initial/final ratings or the students' median project grades. Only confirmed absence can be recorded as 0; an inaccessible file or unresolved intake flag remains pending.

## Record templates

Record submission ID, TA ID, packet version, skill revision, assessment date, and AI model/run identifier. For every initial human assessment and independent AI assessment:

| Criterion | Rating | Maximum | Exact points | Located evidence | Descriptor rationale | Verification status |
| --- | --- | --- | --- | --- | --- | --- |

Use these exact names and maxima in this order, matching the PDF:

| Criterion | Maximum |
| --- | --- |
| Analysis | 20 |
| Visualization quality and accuracy | 10 |
| Interpretation and limitations | 15 |
| Business decision and recommendation | 10 |
| Data preparation and reproducibility | 15 |
| Technical report communication | 15 |
| Executive summary | 15 |

For the TA's personal reconciliation:

| Criterion | TA initial rating + evidence | AI initial rating + evidence | Agreement/disagreement and check | TA final rating + evidence | Reason for keeping/changing |
| --- | --- | --- | --- | --- | --- |

Maintain the initial TA total, initial AI total, final TA total, and unresolved flags. A total alone is insufficient for an auditable final assessment.

## Calculator

`scripts/score.py` uses only Python's standard library. Resolve its path relative to this skill folder. Commands below assume the working directory is that folder; use your environment's Python executable.

```text
python scripts/score.py score --ratings 3 3 3 3 3 3 3
python scripts/score.py median final-ta-ratings.json
```

The seven ratings must be integers 0-4, in the PDF order above. Criterion points remain exact. The calculator uses decimal half-up rounding only for each TA's final total to one decimal (e.g., 81.25 becomes 81.3); the rubric specifies one decimal but does not specify a tie-breaking convention. Use this convention consistently unless the instructor specifies another. It emits the exact median of the rounded, TA-assigned totals without an extra rounding step.

The median input represents **one student only**, with the complete expected TA roster and actual finalized TA choices. Example structure (illustrative ratings, not a graded submission):

```json
{
  "student_id": "anonymous-001",
  "expected_ta_ids": ["TA-1", "TA-2"],
  "records": [
    {
      "ta_id": "TA-1",
      "stage": "final-ta",
      "finalized": true,
      "ratings": [3, 3, 3, 3, 3, 3, 3]
    },
    {
      "ta_id": "TA-2",
      "stage": "final-ta",
      "finalized": true,
      "ratings": [4, 4, 4, 4, 4, 4, 4]
    }
  ]
}
```

The calculator is an arithmetic aid. Evidence remains in the assessment/reconciliation records, which must be checked before setting `finalized` to true. It rejects incomplete/duplicate rosters, invalid ratings, and non-final records. It recomputes TA totals from their ratings and reports their range and median. A large range is a review cue, not a new deduction or a reason to force consensus. Never include an AI record as a TA, use a category-wise median, omit an expected TA, or insert zero for a missing grade. If there is an even TA count, the median is the mean of the two middle totals. Any final gradebook rounding or late adjustment needs an instructor-defined rule.

## Instructor checks during and after grading

Review a small sample spanning both objectives, borderline grades, large TA disagreements, and unusually uniform AI reports. Check that evidence exists, ratings match descriptors, and the same defect was not repeatedly penalized. Grade in varying or randomized order and compare early/late calibration to detect drift. Keep final TA choices private until everyone has finalized so discussion does not push every TA toward the same score.

If a shared grading interpretation changes, log the clarification and revisit every affected submission, including already graded work. Give students concise feedback tied to evidence and rubric criteria; retain the full audit record for questions or appeals. The median reduces the influence of one unusually high/low grader, but it does not correct shared misunderstanding, anchoring, or missing evidence.
