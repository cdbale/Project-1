# Overseer and fresh student assessment agents

Use actual delegation tools, not a role-played "agent" inside the same conversation. The overseer coordinates the class; each new worker independently assesses one student. The TA still personally decides final ratings after reconciliation.

## Dispatch with no inherited grading context

After collecting originals, create a new worker for each student ready for assessment. Queue within the environment's actual concurrency limit; even sequential work requires a new agent for every student. Do not fork the parent's conversation or reuse a completed worker for another student.

When the spawning tool exposes `fork_turns`, explicitly use `fork_turns="none"`; an equivalent fresh-context setting is acceptable in another runtime. Do not leave a history-inheriting default in place and merely say "start fresh" in the prompt. Confirm the tool supports no-history creation before dispatch. Normal platform instructions and common rubric rules may remain; prior task conversations and grading results may not.

If fresh-context delegation is unavailable or cannot be established, complete unaffected intake, flag assessment as pending, and tell the TA that automatic isolated assessment is unavailable. Provide a prompt for separate fresh student chats if the TA chooses that manual route. Never silently substitute grading all students in the overseer chat or label simulated delegation as isolated.

## Explicit worker input packet

Assign role **assessment worker** and one Canvas course/user ID and attempt. Supply only:

- Skill path, `rubric-v2.md`, `project-context.md`, official assignment/rubric files, raw `ifood.csv`, and common instructor clarifications. These are the same baseline for every worker.
- That student's original executive summary, technical report, and relevant submitted attachments; their filtered intake manifest, name/section, selected attempt, and factual intake clarifications.
- The student's output folder and the expected six-column assessment workbook/result contract.

The briefing must contain no TA ratings, TA evidence selections, existing Canvas grades, prior AI ratings for that student, or other students' assessments. Do not pass the entire roster, root score CSV, shared Google grading spreadsheet, parent summary/history, or global grading notes as worker inputs. Exclude grading fields before saving or presenting Canvas intake data.

Workers use only the supplied common inputs and assigned student's files. Shared filesystem access is not a security boundary: do not claim technical file isolation unless it exists. Use a restricted per-student workspace/access scope when supported; otherwise explicitly prohibit reading other folders, trackers, or agent results. A worker may contact the overseer for factual missing-input questions, but must not request a preferred score or comparative grading guidance. It does not launch additional workers or collect the class from Canvas.

Example worker briefing, with actual paths/IDs substituted:

```text
You are the assessment worker for course [course ID], student [user ID],
attempt [attempt]. Use grade-mktg-411-project-1 at [skill path], its rubric
and project context, the official PDFs, and raw data at [common paths].
Your only student inputs are [original file paths] and [filtered manifest].
Your output directory is [assigned student folder]. Do not inherit/read
parent grading history, TA assessments, existing grades, other student files,
the class CSV, shared grading sheet, or other agents' results. Do not spawn
agents or perform class intake. Independently apply all seven criteria,
create AI_Assessment.xlsx with the required six columns, and return the
structured result and exact evidence/verification limitations to the overseer.
```

## Results and file ownership

One worker owns one student's assessment outputs. It writes `AI_Assessment.xlsx` and `assessment_result.json` in that student's folder, preserving any earlier output before corrections. Return the same structured result to the overseer. Include course/user ID, attempt, worker ID, actual context-isolation setting, grading packet version, original input paths, workbook path, all seven criterion records, total/status, review flags, and `penguin_sentence_present`.

Each criterion record contains the exact criterion name/maximum, integer rating 0-4 or null for withheld, exact points or null, located evidence, descriptor rationale, and uncertainty. Keep overall grade null for unresolved/withheld cases as required by the skill; never prorate. Record the penguin indicator as 0, 1, or null, with a source location for an occurrence. Distinguish verified reproduction from static review. The JSON is an internal transfer/audit record; it does not add columns to the requested workbook table.

Only the overseer writes or updates the root `AI_Assigned_Scores.csv`, run-level dispatch metadata, or roster status. Workers never edit or read the root CSV. For an intake-blocked student not yet assessable, the overseer can create a pending status row/report without inventing ratings; dispatch a fresh worker when inputs or confirmed-absence guidance are available.

## Overseer review and completion

Before accepting a result, verify the student/attempt/input identity, all seven criterion records and evidence locators, workbook existence/readability, arithmetic and totals, and indicator/status consistency. Recompute weighted points with the existing calculator and confirm the workbook and returned record agree. This is a completeness/evidence/arithmetic check, not a second grading judgment or a way to impose a distribution. Do not revise ratings to resemble other students or an expected TA score.

Send specific factual or output corrections to the same worker only for its assigned student, without exposing other grades or a desired rating. Preserve its original result and correction reason. If a worker received prior grading context, mark the attempt invalid for blind assessment and replace it with a newly spawned no-history worker using only original allowed inputs. Do not pass the invalid assessment to the replacement worker. Retain incomplete/failed rows as pending and continue unaffected students; avoid rerunning until a preferred score appears.

Record each dispatched student's worker ID, actual no-history setting, input/attempt version, completion status, and output paths in run metadata. Do not assert isolation solely because the worker is named differently. Report complete/pending counts and any isolation failures to the TA. Return the fixed AI outputs for the TA's personal reconciliation. The overseer does not read the TA's initial assessment, enter reconciled grades into the shared Google spreadsheet, or post Canvas grades.
