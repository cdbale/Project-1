#!/usr/bin/env python3
"""Calculate PDF Rubric V2 points and a complete roster's final TA median."""
import argparse
import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

CRITERIA = (
    ('Analysis', 20),
    ('Visualization quality and accuracy', 10),
    ('Interpretation and limitations', 15),
    ('Business decision and recommendation', 10),
    ('Data preparation and reproducibility', 15),
    ('Technical report communication', 15),
    ('Executive summary', 15),
)


def score(ratings):
    if not isinstance(ratings, list) or len(ratings) != len(CRITERIA):
        raise ValueError('Exactly seven ratings are required, in PDF criterion order.')
    if any(type(r) is not int or not 0 <= r <= 4 for r in ratings):
        raise ValueError('Ratings must be integers from 0 through 4; booleans are invalid.')
    points = [Decimal(maximum) * rating / 4
              for (_, maximum), rating in zip(CRITERIA, ratings)]
    exact = sum(points, Decimal(0))
    total = exact.quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)
    return {
        'criteria': [{'criterion': name, 'maximum': maximum, 'rating': rating,
                      'points': str(value)}
                     for (name, maximum), rating, value in zip(CRITERIA, ratings, points)],
        'exact_total': str(exact),
        'total': str(total),
        'rounding': 'decimal half-up to one decimal, after summing exact points',
    }


def median_final_ta(packet):
    if not isinstance(packet, dict):
        raise ValueError('Median input must be a JSON object for one student.')
    student_id = packet.get('student_id')
    if not isinstance(student_id, str) or not student_id.strip():
        raise ValueError('A nonempty student_id is required.')
    expected = packet.get('expected_ta_ids')
    if (not isinstance(expected, list) or not expected
            or any(not isinstance(t, str) or not t.strip() for t in expected)
            or len(set(expected)) != len(expected)):
        raise ValueError('expected_ta_ids must be a nonempty list of unique TA IDs.')
    records = packet.get('records')
    if not isinstance(records, list):
        raise ValueError('records must contain one finalized record per expected TA.')
    totals = {}
    for record in records:
        if not isinstance(record, dict):
            raise ValueError('Each TA record must be an object.')
        ta = record.get('ta_id')
        if not isinstance(ta, str) or ta not in expected or ta in totals:
            raise ValueError('A TA is unexpected, missing an ID, or duplicated.')
        if record.get('stage') != 'final-ta' or record.get('finalized') is not True:
            raise ValueError('Only explicitly finalized final-ta records may be aggregated.')
        totals[ta] = Decimal(score(record.get('ratings'))['total'])
    missing = sorted(set(expected) - set(totals))
    if missing:
        raise ValueError('Missing finalized TA grades: ' + ', '.join(missing))
    ordered = sorted(totals.values())
    middle = len(ordered) // 2
    result = (ordered[middle] if len(ordered) % 2
              else (ordered[middle - 1] + ordered[middle]) / 2)
    return {
        'student_id': student_id,
        'final_ta_totals': {ta: str(totals[ta]) for ta in expected},
        'sorted_totals': [str(t) for t in ordered],
        'median': str(result),
        'range': str(ordered[-1] - ordered[0]),
        'ta_count': len(ordered),
        'aggregation': 'median of finalized TA total grades; no extra median rounding',
    }


def unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    single = sub.add_parser('score', help='Seven ratings in PDF order')
    single.add_argument('--ratings', type=int, nargs=7, required=True)
    aggregate = sub.add_parser('median', help='Complete finalized TA roster for one student')
    aggregate.add_argument('input', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'score':
            result = score(args.ratings)
        else:
            packet = json.loads(args.input.read_text(encoding='utf-8-sig'),
                                object_pairs_hook=unique_keys)
            result = median_final_ta(packet)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
