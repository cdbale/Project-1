MKTG 411 Project 1 grading resources
Package prepared October 12, 2026

START HERE
Extract the entire ZIP into a private course folder on your computer.
Open Project_1_TA_Grading_Guide.docx and complete its Initial setup steps.
Keep the extracted Materials and complete skills folder structure intact.
Do not work directly inside the ZIP.

CONTENTS
Project_1_TA_Grading_Guide.docx: role-specific setup and grading workflow.
Materials/Project 1 Instructions.pdf: official assignment and data dictionary.
Materials/Rubric V2.pdf: official rubric.
Materials/ifood.csv: required raw starting data.
Materials/Executive Summary Example.pdf and Technical_Report_Example.qmd:
  teaching examples, not answer keys or additional grading requirements.
  The QMD and raw CSV are together so its relative data path is preserved.
skills/grade-mktg-411-project-1/: complete overseer skill, all references,
  agent metadata, and the deterministic Python score calculator.

AI SETUP
Give the AI the extracted folder path and ask it to read
skills/grade-mktg-411-project-1/SKILL.md and its linked references.
If the skill is not installed, replace its $grade-mktg-411-project-1
invocation in the guide's prompts with "use the skill at [full SKILL.md path]."
An installed copy must match this package's fresh-agent overseer version.
Use an environment that can create a fresh assessment agent per student
without inherited conversation history. If unsupported, assessment stays
pending as described in the skill; do not simulate isolated agents.

STORAGE AND SEPARATELY PROVIDED ITEMS
Let the AI ask where to create a separate Project_1_Grading folder for
student originals, AI_Assessment.xlsx files, assessment_result.json files,
and the root AI_Assigned_Scores.csv. Keep initial TA judgments outside
both the resource folder and the student grading folder, unavailable to AI.
Obtain Canvas access, the live roster, the previous semester's Google Drive
spreadsheet, and any new instructor clarifications separately. Credentials
and student records are not included. The TA team copies the previous sheet
for this semester, preserving median formulas. TAs personally reconcile
their grades, enter final TA totals, and post instructor-approved medians.

The penguin sentence is a review indicator only and changes no points.
Each student's final project grade is the median of final TA total grades.
AI scores do not receive an extra vote.
